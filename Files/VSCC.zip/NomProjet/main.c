/// @brief Fonction principale.
/// @return Code de fin de programme.
int main() {
	return 0;
}