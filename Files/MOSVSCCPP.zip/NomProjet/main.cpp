#include <iostream>

int main() {
  std::cout << "Bonjour le monde!" << std::endl;

  return 0;
}