#include <stdio.h>

int main() {
  puts("Bonjour le monde!");

  return 0;
}
