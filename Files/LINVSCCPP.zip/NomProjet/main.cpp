#include <iostream>

int main(int argc, char* argv[]) {
  std::cout << "Bonjour le monde!" << std::endl;

  return 0;
}
